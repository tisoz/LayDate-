layui.config({
    base: './'
}).extend({
    treeSelect: 'treeSelect/treeSelect'
});